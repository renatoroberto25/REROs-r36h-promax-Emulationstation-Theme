# RENATO // NEON

Tema cyberpunk verde neon e roxo para EmulationStation / ArkOS.
Layout 4:3, com assets em 1024 × 768 e posições proporcionais.

![Prévia ilustrativa](docs/preview.png)

Primeira versão: seleção de sistemas, listas simples/detalhadas, vídeo,
menus e cores da tela de carregamento. Inclui 223 logos e uma imagem
de reserva para jogos sem capa. Capas, vídeos e descrições vêm da biblioteca
do console. Relógio, bateria e rede dependem do suporte do firmware.

## Instalar no console

1. Extraia `dist/RENATO-THEME.zip` na pasta `themes` da partição EASYROMS.
   O resultado deve ser `themes/RENATO-THEME/theme.xml`.
2. No console: **START → UI Settings → Theme → RENATO-THEME**.
3. Use a visualização de lista **Basic**, **Detailed** ou **Video**.

No Linux, a pasta de destino deste cartão é
`/run/media/renato/EASYROMS/themes/RENATO-THEME/`.
O pacote foi preparado localmente; o cartão ainda não foi atualizado.
O `theme.xml` da cópia original estava vazio e foi reconstruído aqui.

As instruções de instalação seguem a [wiki de temas do ArkOS](https://github.com/christianhaitian/arkos/wiki/Themes).
As prévias são simulações com os assets e as medidas do tema, não capturas
do aparelho. O teste final de navegação, vídeo e indicadores deve ser feito
no R36H Pro Max.

## Ajustar o visual

- Textos, fontes, cores da interface e posições: `theme.xml`.
- Fundos editáveis: `_inc/neon/*-bg.svg`.
- Logo de cada sistema: `_inc/neon/logos/<sistema>.svg`.
- Cores do carregamento: `splash.xml`.

No projeto completo desta pasta, depois de editar um SVG, regenere os PNGs:

```sh
python3 scripts/build_assets.py
python3 scripts/preview.py
python3 scripts/package.py
```

Os dois primeiros comandos precisam de CairoSVG; a prévia também usa Pillow.
O ZIP contém os arquivos de instalação; os scripts ficam no projeto completo.
O console não precisa de Python.

## Créditos e referências

- Base e assets herdados: `simple-theme`, cujos XMLs identificam
  Art Book 4:3 / Szalik e licença CC BY-NC-SA. Os originais em `_inc/systems`
  foram preservados; as cópias de logos em `_inc/neon/logos` têm dimensões
  normalizadas. Marcas e logos pertencem aos respectivos titulares.
- Rajdhani Bold: Indian Type Foundry, [Google Fonts](https://github.com/google/fonts/tree/main/ofl/rajdhani).
  Licença SIL OFL em `_inc/fonts/Rajdhani-OFL.txt`.
- Cabin Bold: Pablo Impallari / Igino Marini, herdada da base.
  Licença SIL OFL em `_inc/fonts/Cabin-OFL.txt`, com o aviso extraído da fonte.
- Fundos e ícone de cartucho: criados para este tema.
- Referência técnica: [EmulationStation usado pelo ArkOS](https://github.com/christianhaitian/EmulationStation-fcamod).
